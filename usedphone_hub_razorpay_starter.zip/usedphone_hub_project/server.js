const express = require('express');
const crypto = require('crypto');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const KEY_ID = process.env.RAZORPAY_KEY_ID;
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET;

// Demo catalogue: amounts are determined on the server, not trusted from the browser.
const catalogue = {
  iphone13: { name: 'iPhone 13', amount: 2850000 },
  s22: { name: 'Samsung Galaxy S22', amount: 2499900 },
  oneplus11r: { name: 'OnePlus 11R', amount: 1899900 },
  iphone12: { name: 'iPhone 12', amount: 2150000 },
  s21fe: { name: 'Samsung S21 FE', amount: 1599900 },
  nord3: { name: 'OnePlus Nord 3', amount: 1399900 },
  redmi12: { name: 'Redmi Note 12 Pro', amount: 999900 },
  iphone14: { name: 'iPhone 14', amount: 3699900 }
};

// Replace this in-memory store with a persistent database before production.
const orders = new Map();

app.use(express.static(path.join(__dirname, 'public')));

// Razorpay webhooks need the raw request body for signature validation.
app.post('/api/razorpay-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  if (!WEBHOOK_SECRET) return res.status(503).send('Webhook secret is not configured');
  const signature = req.header('x-razorpay-signature') || '';
  const expected = crypto.createHmac('sha256', WEBHOOK_SECRET).update(req.body).digest('hex');
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).send('Invalid signature');
  const event = JSON.parse(req.body.toString('utf8'));
  // In production, persist event id and payment state idempotently in your database.
  if (event.event === 'payment.captured' || event.event === 'order.paid') {
    console.log('Razorpay paid event received:', event.event);
  }
  res.json({ received: true });
});

app.use(express.json({ limit: '20kb' }));

app.post('/api/create-order', async (req, res) => {
  try {
    if (!KEY_ID || !KEY_SECRET) return res.status(503).json({ error: 'Razorpay keys are not configured on the server yet.' });
    const { productId, buyerName, buyerPhone } = req.body || {};
    const product = catalogue[productId];
    if (!product) return res.status(400).json({ error: 'Invalid product selected.' });
    if (typeof buyerName !== 'string' || buyerName.trim().length < 2) return res.status(400).json({ error: 'Enter a valid buyer name.' });
    if (typeof buyerPhone !== 'string' || !/^[6-9]\d{9}$/.test(buyerPhone)) return res.status(400).json({ error: 'Enter a valid Indian mobile number.' });

    const receipt = `uph_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${KEY_ID}:${KEY_SECRET}`).toString('base64'),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ amount: product.amount, currency: 'INR', receipt, notes: { productId, productName: product.name, buyerName: buyerName.trim(), buyerPhone } })
    });
    const order = await response.json();
    if (!response.ok) return res.status(502).json({ error: order.error?.description || 'Razorpay order creation failed.' });
    orders.set(order.id, { amount: product.amount, productId, status: 'created', createdAt: Date.now() });
    res.json({ keyId: KEY_ID, orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error while creating payment order.' });
  }
});

app.post('/api/verify-payment', (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  const stored = orders.get(razorpay_order_id);
  if (!stored) return res.status(400).json({ error: 'Order not found. Please retry checkout.' });
  if (![razorpay_order_id, razorpay_payment_id, razorpay_signature].every(v => typeof v === 'string')) {
    return res.status(400).json({ error: 'Incomplete payment response.' });
  }
  const expected = crypto.createHmac('sha256', KEY_SECRET || '').update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  const a = Buffer.from(razorpay_signature);
  const b = Buffer.from(expected);
  if (!KEY_SECRET || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(400).json({ error: 'Payment signature verification failed.' });
  }
  stored.status = 'signature_verified';
  stored.paymentId = razorpay_payment_id;
  res.json({ verified: true, orderId: razorpay_order_id, message: 'Payment signature verified.' });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'UsedPhone Hub' }));

app.listen(PORT, () => console.log(`UsedPhone Hub running at http://localhost:${PORT}`));
