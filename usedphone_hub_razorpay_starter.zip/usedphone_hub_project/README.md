# UsedPhone Hub — starter project

A responsive used-phone marketplace front end with a Razorpay Standard Checkout integration scaffold.

## What is included
- Responsive UsedPhone Hub storefront and demo phone catalogue.
- Search and brand filters.
- Demo sell-listing form (not persisted or visible to other visitors).
- Checkout form that calls a server to create a Razorpay order.
- Server-side payment signature verification.
- Razorpay webhook signature verification endpoint.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run: `npm install`
3. Copy `.env.example` to `.env`.
4. Add your Razorpay **test** Key ID and Key Secret from the Razorpay Dashboard to `.env`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Do not share or paste API secrets into chat or frontend HTML. Keep `.env` private and never commit it to a public repository.

## Razorpay setup
- Create and complete merchant onboarding in Razorpay Dashboard.
- Generate test API keys first.
- For webhook testing, configure your deployed HTTPS webhook URL as `/api/razorpay-webhook`, use the same webhook secret in `.env`, and subscribe to `payment.captured` and `order.paid`.
- Test the complete checkout and verify captured status in the Razorpay Dashboard.
- Only after Razorpay approves your account and you finish its go-live checklist, switch to live keys.

Official docs:
- Standard Checkout integration: https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/
- Razorpay Node integration: https://razorpay.com/docs/payments/server-integration/nodejs/

## Important production work still required
This is a starter, not a production-ready marketplace. Before accepting real customers:
- Use a persistent database for users, listings, orders, inventory, and payment states. The sample server uses in-memory order storage.
- Add authentication, seller verification, listing photo uploads, admin moderation, rate limiting, CSRF/origin protections, audit logs, privacy policy, terms, refund/cancellation and dispute flows.
- Fetch payment/order status from Razorpay or reconcile through signed webhooks before marking an order paid or releasing a phone. Signature verification alone should be followed by payment-status confirmation.
- Define seller payouts and marketplace/aggregator compliance with Razorpay before collecting money for multiple independent sellers. A normal merchant settlement to one bank account is not an escrow or split-settlement solution.
- Deploy behind HTTPS and configure production environment variables securely.

The catalogue and listing form are demonstration data. The seller listing form only adds a listing in the current browser session.
